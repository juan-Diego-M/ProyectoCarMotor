/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Historial;

/**
 *
 * @author Juan Diego Martínez – 20231020131
 * @author Luis Felipe Suárez – 2023102033
 * @author Carlos Brito – 20241020147
 * @author Iván López – 20232020113
 */
public class ReporteMantenimientos {
    private double total;
    private String reporte;
    public ReporteMantenimientos() {}
    public void visitarSimple(Object m) {}
    public void visitarIVA(Object m) {}
    public void visitarDescuento(Object m) {}
    public void visitarCertificado(Object m) {}
    public String getReporte(){ return null; }
}
